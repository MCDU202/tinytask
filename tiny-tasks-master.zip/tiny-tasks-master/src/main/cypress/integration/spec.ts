describe('Tiny Task', () => {
  it('Visits the initial page', () => {
    cy.visit('/');
  });
});
