export const environment = {
  production: false,
  useLocalStorage: true
};
