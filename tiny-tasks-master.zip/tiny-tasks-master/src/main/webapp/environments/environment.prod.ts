export const environment = {
  production: true,
  useLocalStorage: false
};
