/**
 * A tiny task.
 */
export interface Task {
  id: string;
  name: string;
}
